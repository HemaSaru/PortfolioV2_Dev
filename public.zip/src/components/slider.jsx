export default function TextSlider() {
    return (
      <div className="w-full overflow-hidden bg-gray-100 py-4">
        <div className="animate-slide whitespace-nowrap text-2xl font-bold text-purple-700">
          My name is Hema
        </div>
      </div>
    );
  }
  